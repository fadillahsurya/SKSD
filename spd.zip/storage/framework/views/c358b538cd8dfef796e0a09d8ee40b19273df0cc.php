<?php $__env->startSection('title', 'Surat'); ?>

<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
<style>
    .ikon {
        font-family: fontAwesome;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="card shadow h-100">
                    <div class="card-header border-0">
                        <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-between text-center text-md-left">
                            <div class="mb-3">
                                <h2 class="mb-0">Surat</h2>
                                <p class="mb-0 text-sm">Kelola Surat <?php echo e(config('app.name')); ?></p>
                            </div>
                            <div class="mb-3">
                                <a href="<?php echo e(route('surat.create')); ?>" class="btn btn-success" title="Tambah"><i class="fas fa-plus"></i> Tambah Surat</a>
                            </div>
                        </div>
                        <form class="navbar-search mt-3 cari-none">
                            <div class="form-group mb-0">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    </div>
                                    <input class="form-control" placeholder="Cari ...." type="text" name="cari" value="<?php echo e(request('cari')); ?>">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form-search'); ?>
<form class="navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto">
    <div class="form-group mb-0">
        <div class="input-group input-group-alternative">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
            </div>
            <input class="form-control" placeholder="Cari ...." type="text" name="cari" value="<?php echo e(request('cari')); ?>">
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="card" class="row mt-4 justify-content-center">
    <?php $__empty_1 = true; $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4 col-md-6 surats">
            <div class="single-service bg-white rounded shadow">
                <a href="<?php echo e(route('surat.show', $item)); ?>">
                    <i class="fas <?php echo e($item->icon); ?> ikon fa-5x mb-3"></i>
                    <h4><?php echo e($item->nama); ?></h4>
                </a>
                <p><?php echo e($item->deskripsi); ?></p>
                <?php if($item->cetakSurat->count() > 0): ?>
                    <p class="text-sm text-muted">Telah dicetak sebanyak <?php echo e($item->cetakSurat->count()); ?>x</p>
                <?php endif; ?>
                <?php if($item->tampilkan == 0): ?>
                    <p class="font-weight-bold">(Belum ditampilkan)</p>
                    <a href="<?php echo e(route('buat-surat', ['id' => $item->id,'slug' => Str::slug($item->nama)])); ?>" class="btn btn-sm btn-success" title="Cetak"><i class="fas fa-print"></i> Coba cetak</a>
                <?php endif; ?>
                <a href="<?php echo e(route('surat.edit', $item)); ?>" class="btn btn-sm btn-primary" title="Edit"><i class="fas fa-edit"></i> Edit</a>
                <a class="btn btn-sm btn-danger hapus-data" data-nama="<?php echo e($item->nama); ?>" data-action="<?php echo e(route('surat.destroy', $item)); ?>" data-toggle="modal" href="#modal-hapus" title="Hapus"><i class="fas fa-trash"></i> Hapus</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col">
            <div class="single-service bg-white rounded shadow">
                <h4>Data belum tersedia</h4>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="modal fade" id="modal-hapus" tabindex="-1" role="dialog" aria-labelledby="modal-hapus" aria-hidden="true">
    <div class="modal-dialog modal-danger modal-dialog-centered modal-" role="document">
        <div class="modal-content bg-gradient-danger">

            <div class="modal-header">
                <h6 class="modal-title" id="modal-title-delete">Hapus Surat?</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>

            <div class="modal-body">

                <div class="py-3 text-center">
                    <i class="ni ni-bell-55 ni-3x"></i>
                    <h4 class="heading mt-4">Perhatian!!</h4>
                    <p>Menghapus surat akan menghapus semua data yang dimilikinya</p>
                    <p><strong id="nama-hapus"></strong></p>
                </div>

            </div>

            <div class="modal-footer">
                <form id="form-hapus" action="" method="POST" >
                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-white">Yakin</button>
                </form>
                <button type="button" class="btn btn-link text-white ml-auto" data-dismiss="modal">Tidak</button>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        $('[name="cari"]').on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#card .surats").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sitemdesa-main\resources\views/surat/index.blade.php ENDPATH**/ ?>