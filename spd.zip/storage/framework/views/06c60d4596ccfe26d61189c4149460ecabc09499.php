<?php $__env->startSection('title', 'Website Resmi Pemerintah Desa '. $desa->nama_desa .' - Beranda'); ?>

<?php $__env->startSection('styles'); ?>
<meta name="description"
    content="Website Resmi Pemerintah Desa <?php echo e($desa->nama_desa); ?>, Kecamatan <?php echo e($desa->nama_kecamatan); ?>, Kabupaten <?php echo e($desa->nama_kabupaten); ?>. Melayani pembuatan surat keterangan secara online">

<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
<style>
    .ikon {
        font-family: fontAwesome;
    }

    .progress-label>span {
        color: white;
    }

    .progress-percentage>span {
        color: white;
    }

    .judul {
        color: white;
    }

    .animate-up:hover {
        top: -5px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-white text-sm text-muted">SELAMAT DATANG DI WEBSITE RESMI</h1>
<h2 class="text-lead text-white">DESA <?php echo e(Str::upper($desa->nama_desa)); ?> <br> KECAMATAN <?php echo e(Str::upper($desa->nama_kecamatan)); ?> <br />KABUPATEN <?php echo e(Str::upper($desa->nama_kabupaten)); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md">
        <div id="owl-one" class="owl-carousel owl-theme" style="z-index: 0">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="text-center" href="<?php echo e(asset(Storage::url($item->gallery))); ?>" data-caption="<?php echo e($item->caption); ?>"
                data-fancybox>
                <img src="<?php echo e(asset(Storage::url($item->gallery))); ?>" alt="Slide Show <?php echo e($key); ?>"
                    style="max-height: 500px; object-fit: contain;">
                <p class="text-center text-white"><?php echo e($item->caption); ?></p>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php if($surat->count() > 0): ?>
<section class="mb-5">
    <div class="row">
        <div class="col-md">
            <div class="header-body text-center mt-5 mb-3">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6 border-bottom">
                        <h2 class="text-white">LAYANAN SURAT</h2>
                        <p class="text-white">Dengan menggunakan layanan surat website Desa <?php echo e($desa->nama_desa); ?>,
                            masyarakat dapat dengan mudah membuat beberapa surat keterangan berikut ini secara online.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4 justify-content-center">
        <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 surats">
            <div class="single-service bg-white rounded shadow p-3 animate-up">
                <a href="<?php echo e(route('buat-surat', ['id' => $item->id,'slug' => Str::slug($item->nama)])); ?>">
                    <i class="fas <?php echo e($item->icon); ?> ikon fa-5x mb-3"></i>
                    <h4><?php echo e($item->nama); ?></h4>
                </a>
                <p><?php echo e($item->deskripsi); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(App\Surat::count() > 3): ?>
        <a href="<?php echo e(route('layanan-surat')); ?>" class="btn btn-primary">Lebih Banyak Surat</a>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<?php if($berita->count() > 0): ?>
<section class="mb-5">
    <div class="row">
        <div class="col-md">
            <div class="header-body text-center mt-5 mb-3">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6 border-bottom">
                        <h2 class="text-white">BERITA</h2>
                        <p class="text-white">Berita Desa <?php echo e($desa->nama_desa); ?>, masyarakat dapat dengan mudah
                            mengetahui informasi seputar berita desa <?php echo e($desa->nama_desa); ?>.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 mb-3">
            <div class="card animate-up shadow">
                <a href="<?php echo e(route('berita.show', ['berita' => $item, 'slug' => Str::slug($item->judul)])); ?>">
                    <div class="card-img"
                        style="background-image: url('<?php echo e($item->gambar ? url(Storage::url($item->gambar)) : url(Storage::url('noimage.jpg'))); ?>'); background-size: cover; height: 200px;">
                    </div>
                </a>
                <div class="card-body text-center">
                    <a href="<?php echo e(route('berita.show', ['berita' => $item, 'slug' => Str::slug($item->judul)])); ?>">
                        <h3><?php echo e($item->judul); ?></h3>
                        <div class="mt-3 d-flex justify-content-between text-sm text-muted">
                            <i class="fas fa-clock"> <?php echo e($item->created_at->diffForHumans()); ?></i>
                            <i class="fas fa-eye"> <?php echo e($item->dilihat); ?> Kali Dibaca</i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if(App\Berita::count() > 3): ?>
    <div class="text-center">
        <a href="<?php echo e(route('berita')); ?>" class="btn btn-primary">Lebih Banyak Berita</a>
    </div>
    <?php endif; ?>
</section>
<?php endif; ?>
<?php if($pemerintahan_desa->count() > 0): ?>
<section class="mb-5">
    <div class="row">
        <div class="col-md">
            <div class="header-body text-center mt-5 mb-3">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6 border-bottom">
                        <h2 class="text-white">Pemerintahan Desa</h2>
                        <p class="text-white">Pemerintahan Desa <?php echo e($desa->nama_desa); ?>, masyarakat dapat dengan mudah
                            mengetahui informasi seputar pemerintahan desa <?php echo e($desa->nama_desa); ?>.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <?php $__currentLoopData = $pemerintahan_desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 mb-3">
            <div class="card animate-up shadow">
                <a
                    href="<?php echo e(route('pemerintahan-desa.show', ['pemerintahan_desa' => $item, 'slug' => Str::slug($item->judul)])); ?>">
                    <div class="card-img"
                        style="background-image: url('<?php echo e($item->gambar ? url(Storage::url($item->gambar)) : url(Storage::url('noimage.jpg'))); ?>'); background-size: cover; height: 200px;">
                    </div>
                </a>
                <div class="card-body text-center">
                    <a
                        href="<?php echo e(route('pemerintahan-desa.show', ['pemerintahan_desa' => $item, 'slug' => Str::slug($item->judul)])); ?>">
                        <h3><?php echo e($item->judul); ?></h3>
                        <div class="mt-3 d-flex justify-content-between text-sm text-muted">
                            <i class="fas fa-clock"> <?php echo e($item->created_at->diffForHumans()); ?></i>
                            <i class="fas fa-eye"> <?php echo e($item->dilihat); ?> Kali Dibaca</i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if(App\PemerintahanDesa::count() > 3): ?>
    <div class="text-center">
        <a href="<?php echo e(route('pemerintahan-desa')); ?>" class="btn btn-primary">Lebih Banyak Informasi Pemerintahan Desa</a>
    </div>
    <?php endif; ?>
</section>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('js/apbdes.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('#owl-one').owlCarousel({
            loop: true,
            autoplay: true,
            autoplayTimeout: 3000,
            autoplayHoverPause: true,
            smartSpeed:1000,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            }
        });
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sitemdesa-main\resources\views/index.blade.php ENDPATH**/ ?>