<?php $__env->startSection('title', 'Website Resmi Pemerintah Desa '. App\Desa::find(1)->nama_desa . ' - Statistik Penduduk'); ?>

<?php $__env->startSection('styles'); ?>
<meta name="description" content="Statistik Penduduk Desa <?php echo e(App\Desa::find(1)->nama_desa); ?>, Kecamatan <?php echo e(App\Desa::find(1)->nama_kecamatan); ?>, Kabupaten <?php echo e(App\Desa::find(1)->nama_kabupaten); ?>.">
<script src="https://code.highcharts.com/stock/highstock.js"></script>
<script src="https://code.highcharts.com/stock/modules/exporting.js"></script>
<script src="https://code.highcharts.com/stock/modules/accessibility.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-white text-muted">STATISTIK PENDUDUK</h1>
<p class="text-white">Statistik Penduduk Desa <?php echo e($desa->nama_desa); ?>, masyarakat dapat dengan mudah mengetahui informasi mengenai statistik penduduk desa <?php echo e($desa->nama_desa); ?>.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php echo $__env->make('statistik-penduduk.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/statistik-penduduk.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sitemdesa-main\resources\views/statistik-penduduk/index.blade.php ENDPATH**/ ?>