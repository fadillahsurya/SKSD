<?php $__env->startSection('title', 'Website Resmi Pemerintah Desa '. $desa->nama_desa . ' - Pemerintahan Desa'); ?>

<?php $__env->startSection('styles'); ?>
<meta name="description" content="Macam-macam sejarah Desa <?php echo e($desa->nama_desa); ?>, Kecamatan <?php echo e($desa->nama_kecamatan); ?>, Kabupaten <?php echo e($desa->nama_kabupaten); ?>.">

<style>
    .animate-up:hover {
        top: -5px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-white text-muted">PEMERINTAHAN DESA</h1>
<p class="text-white">Pemerintahan Desa <?php echo e($desa->nama_desa); ?>, masyarakat dapat dengan mudah mengetahui informasi seputar pemerintahan desa <?php echo e($desa->nama_desa); ?>.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">

    <?php $__empty_1 = true; $__currentLoopData = $pemerintahan_desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4 col-md-6 mb-3">
            <div class="card animate-up shadow">
                <a href="<?php echo e(route('pemerintahan-desa.show', ['pemerintahan_desa' => $item, 'slug' => Str::slug($item->judul)])); ?>">
                    <div class="card-img" style="background-image: url('<?php echo e($item->gambar ? url(Storage::url($item->gambar)) : url(Storage::url('noimage.jpg'))); ?>'); background-size: cover; height: 200px;"></div>
                </a>
                <div class="card-body text-center">
                    <a href="<?php echo e(route('pemerintahan-desa.show', ['pemerintahan_desa' => $item, 'slug' => Str::slug($item->judul)])); ?>">
                        <h3><?php echo e($item->judul); ?></h3>
                        <div class="mt-3 d-flex justify-content-between text-sm text-muted">
                            <i class="fas fa-clock"> <?php echo e($item->created_at->diffForHumans()); ?></i>
                            <i class="fas fa-eye"> <?php echo e($item->dilihat); ?> Kali Dibaca</i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col">
            <div class="card">
                <div class="card-body text-center">
                    <h3>Data belum tersedia</h3>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="col-12">
        <?php echo e($pemerintahan_desa->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sitemdesa-main\resources\views/pemerintahan-desa/pemerintahan-desa.blade.php ENDPATH**/ ?>