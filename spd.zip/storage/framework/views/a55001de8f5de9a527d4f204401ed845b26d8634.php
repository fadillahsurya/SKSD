<?php $__env->startSection('title'); ?>
Error 404
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <h1 class="text-white">Halaman Tidak Ditemukan</h1>
    <p class="text-lead text-light">ERROR 404</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sitemdesa-main\resources\views/errors/404.blade.php ENDPATH**/ ?>