<?php

return [
    'key' => env('API_KEY', 'KOSONG'),
];
