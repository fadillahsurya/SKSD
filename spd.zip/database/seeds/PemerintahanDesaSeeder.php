<?php

use Illuminate\Database\Seeder;

class PemerintahanDesaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
