<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PemerintahanDesa extends Model
{
    protected $table = 'pemerintahan_desa';
    protected $guarded = [];
}
