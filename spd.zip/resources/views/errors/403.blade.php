@extends('layouts.layout')

@section('title')
Error 403
@endsection

@section('header')
    <h1 class="text-white">Akses dibatasi</h1>
    <p class="text-lead text-light">ERROR 403</p>
@endsection
