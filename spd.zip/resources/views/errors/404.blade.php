@extends('layouts.layout')

@section('title')
Error 404
@endsection

@section('header')
    <h1 class="text-white">Halaman Tidak Ditemukan</h1>
    <p class="text-lead text-light">ERROR 404</p>
@endsection
