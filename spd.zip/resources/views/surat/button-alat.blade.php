<div class="mb-3">
    <button type="button" title="shorcut-key (ctrl + alt + p)" data-toggle="tooltip" id="paragraf" class="btn btn-sm btn-slack mt-2">Paragraf</button>
    <button type="button" title="shorcut-key (ctrl + alt + k)" data-toggle="tooltip" id="kalimat" class="btn btn-sm btn-slack mt-2">Kalimat</button>
    <button type="button" title="shorcut-key (ctrl + alt + i)" data-toggle="tooltip" id="isi" class="btn btn-sm btn-slack mt-2">Isian</button>
    <button type="button" title="shorcut-key (ctrl + alt + j)" data-toggle="tooltip" id="sub-judul" class="btn btn-sm btn-slack mt-2">Sub Judul</button>
    <a href="{{ url('img/bantuan-paragraf-kalimat-isian.png') }}" data-fancybox><i class="fas fa-question-circle text-blue" title="Bantuan" data-toggle="tooltip"></i></a>
</div>
